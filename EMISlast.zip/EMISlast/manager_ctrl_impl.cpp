#include "manager_ctrl_impl.h"
using namespace std;


bool ManagerCtrlImpl::addMgr(Manager& mgr)
{
	mgrarr.insert(mgrarr.end(),mgr);
	return true;
}

bool ManagerCtrlImpl::delMgr(int id)
{
	for(vector<Manager>::iterator it=mgrarr.begin()+1; it!=mgrarr.end(); it++)
	{
		if((*it).getId() == id)
		{
			mgrarr.erase(it);
			return true;	
		}
	}
	return false;
}

vector<Manager>& ManagerCtrlImpl::listMgr(void)
{
	return mgrarr;
}
