touch main.cpp
touch emis.h emis.cpp 
touch tools.h tools.cpp
touch manager_view.h 
touch manager_view_impl.h manager_view_impl.cpp
touch manager_ctrl.h
touch manager_ctrl_impl.h manager_ctrl_impl.cpp
touch manager_mode.h 
touch manager_mode_impl.h manager_mode_impl.cpp
touch manager.h manager.cpp

touch service_view.h
touch service_view_impl.h service_view_impl.cpp
touch service_ctrl.h
touch service_ctrl_impl.h service_ctrl_impl.cpp
touch service_mode.h
touch service_mode_impl.h service_mode_impl.cpp
touch department.h department.cpp 
touch employee.h employee.cpp

touch id.dat managers.dat services.dat

ls *.cpp> Makefile
ls *.cpp *.h>EMIS.conf
