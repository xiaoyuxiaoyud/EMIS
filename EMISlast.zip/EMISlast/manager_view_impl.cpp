#include <iostream>
#include <cstring>
#include <cstdlib>
#include "manager_view_impl.h"
using namespace std;

void ManagerViewImpl::loginManager(void)
{
	cout << "***超级管理员登录界面***" << endl;
	int id = 0;
	char pass[20] = {};
	cout << "请输入 ID：";
	cin >> id;
	cout << "请输入密码：";
	cin >> pass;
	if((mgrCtrl->listMgr().begin())->getId() == id)
	{
		if(strcmp(mgrCtrl->listMgr().begin()->getPwd(),pass) == 0)
		{
			cout << "登录成功" << endl;
			anykeycontinue();	
			menuMgr();
			return;
		}
		else
			cout << "密码错误，请检查!" << endl;			
	}
	else
		cout << "帐号错误，请检查!" << endl;
	anykeycontinue();	
}

void ManagerViewImpl::loginService(void)
{
	cout << "***管理员登录界面***" << endl;
	int id = 0;
	char pass[20] = {};
	cout << "请输入 ID：";
	cin >> id;
	cout << "请输入密码：";
	cin >> pass;
	for(vector<Manager>::iterator it=mgrCtrl->listMgr().begin()+1; it!=mgrCtrl->listMgr().end(); it++)
	{
		if(it->getId() == id)
		{
			if(strcmp(it->getPwd(),pass) == 0)
			{
				cout << "登录成功" << endl;
				anykeycontinue();
				srcView->menuSrc();
				return;
			}
			else
			{
				cout << "密码错误，请检查!" << endl;			
			}
			anykeycontinue();
			return;
		}
	}
	cout << "帐号错误，请检查!" << endl;
	anykeycontinue();
	return;
}

void ManagerViewImpl::menuMgr(void)
{
	while(true)
	{
		system("clear");
		cout << "1、增加管理员" << endl;
		cout << "2、删除管理员" << endl;
		cout << "3、显示所有管理员" << endl;
		cout << "4、返回首页" << endl;
		switch(get_cmd('1','4'))
		{
			case '1':	addMgr();	break;
			case '2':	delMgr();	break;
			case '3':	listMgr();	break;
			case '4':	return;
		}
	}
}

void ManagerViewImpl::addMgr(void)
{
	char name[20];
	char pass[20];
	cout << "请输入用户名：";
	cin >> name;
	cout << "请输入密码：";
	cin >> pass;
	Manager mgr(name,pass);
	if(mgrCtrl->addMgr(mgr))
		cout << "添加成功" << endl;
	else
		cout << "添加失败" << endl;
	anykeycontinue();
}

void ManagerViewImpl::delMgr(void)
{
	int id = 0;
	cout << "请输入管理员的ID号：";
	cin >> id;
	if(mgrCtrl->delMgr(id))
		cout << "删除成功" << endl;
	else
		cout << "删除失败" << endl;
	anykeycontinue();
}

void ManagerViewImpl::listMgr(void)
{
	vector<Manager>& mgrarr = mgrCtrl->listMgr();
	for(vector<Manager>::iterator it=mgrarr.begin(); it!=mgrarr.end(); it++)
	{
		cout << it->getId() << " " << it->getName() << " " << 	it->getPwd() << endl;
	}
	anykeycontinue();
}

