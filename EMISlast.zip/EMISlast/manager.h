#ifndef MANAGER_H
#define MANAGER_H

#include <cstring>
#include "tools.h"
//using namespace std;

class Manager
{
	int m_Id;
	char m_strName[20];
	char m_strPwd[20];
public:
	Manager(const char* name,const char* pass)
	{
		m_Id = get_mgrid();
		strcpy(m_strName,name);
		strcpy(m_strPwd,pass);
	}
	Manager(void)	{}
	int getId(void)const;
	const char* getName(void)const;
	const char* getPwd(void)const;
	void setId(int id);
	void setName(const char* name);
	void setPwd(const char* pwd);
};

#endif//MANAGER_H
