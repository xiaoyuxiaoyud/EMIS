#include <iostream>
#include <fstream>
#include "manager_mode_impl.h"
using namespace std;

void ManagerModeImpl::load(vector<Manager>& mgrarr)
{

	ifstream fin("managers.dat");
	char buf[sizeof(Manager)+2] = {};
	int id = 0;
	char name[20] = {};
	char pass[20] = {};
	Manager mgr;
	while(true)
	{
		fin.read(buf,sizeof(Manager)+2);
		if(!fin.good())	break;
		sscanf(buf,"%d %s %s",&id,name,pass);
		mgr.setId(id);
		mgr.setName(name);
		mgr.setPwd(pass);
		mgrarr.insert(mgrarr.end(),mgr);
	}
	fin.close();
}

void ManagerModeImpl::save(vector<Manager>& mgrarr)
{
	ofstream fout("managers.dat");
	char buf[sizeof(Manager)+2] = {};
	for(vector<Manager>::iterator it=mgrarr.begin(); it!=mgrarr.end(); it++)
	{
		sprintf(buf,"%d %s %s",it->getId(),it->getName(),it->getPwd());
		fout.write(buf,sizeof(buf));
	}
	fout.close();
}
