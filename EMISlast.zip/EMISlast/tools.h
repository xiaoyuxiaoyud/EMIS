#ifndef TOOLS_H
#define TOOLS_H

int get_mgrid(void);
int get_deptid(void);
int get_empid(void);
char get_cmd(const char start,const char end);
void anykeycontinue(void);
void main_show(void);

#endif//TOOLS_H
