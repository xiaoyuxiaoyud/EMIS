#ifndef DEPARTMENT_H
#define DEPARTMENT_H

#include <iostream> 
#include "employee.h"
#include <vector>
using namespace std;

class Department
{
	int m_Id;
	char m_strName[20];
public:
	vector<Employee> empArr;
	Department(const char* name)
	{
		m_Id = get_deptid();
		strcpy(m_strName,name);
	}
	Department(void)	{};
	~Department(void)
	{
		
	}
	void setId(int id);
	void setName(const char* name);
	int getId(void);
	char* getName(void);
	friend ostream& operator<<(ostream& os,const Department& dept);
	friend istream& operator>>(istream& is,Department& dept);
};

#endif//DEPARTMENT_H
