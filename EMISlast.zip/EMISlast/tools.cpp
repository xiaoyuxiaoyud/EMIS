#include <iostream>
#include <fstream>
#include <getch.h>
#include <stdlib.h>
#include "tools.h"
using namespace std;

int get_mgrid(void)
{
	int mgrid=0,deptid=0,empid=0,new_mgrid=0;
	ifstream fin("id.dat");
	fin >> mgrid >> deptid >> empid;
	new_mgrid = mgrid+1;
	fin.close();
	ofstream fout("id.dat");
	fout << new_mgrid << " " << deptid << " " << empid << endl;
	fout.close();
	return mgrid;
}

int get_deptid(void)
{
	int mgrid=0,deptid=0,empid=0,new_deptid=0;
	ifstream fin("id.dat");
	fin >> mgrid >> deptid >> empid;
	new_deptid = deptid+1;
	fin.close();
	ofstream fout("id.dat");
	fout << mgrid << " " << new_deptid << " " << empid << endl;
	fout.close();
	return deptid;
}

int get_empid(void)
{
	int mgrid=0,deptid=0,empid=0,new_empid=0;
	ifstream fin("id.dat");
	fin >> mgrid >> deptid >> empid;
	new_empid = empid+1;
	fin.close();
	ofstream fout("id.dat");
	fout << mgrid << " " << deptid << " " << new_empid << endl;
	fout.close();
	return empid;
}

//	获取键值并回显
char get_cmd(const char start,const char end)
{
	cout << "请输入指令：";
	while(true)
	{
		char cmd = getch();
		if(cmd >= start && cmd <= end)
		{
			cout << cmd << endl;
			return cmd;
		}
	}

}

//	按任意键继续
void anykeycontinue(void)
{
	stdin->_IO_read_ptr = stdin->_IO_read_end;
	cout << "按任意键继续!" << endl;
	getch();
}

void main_show(void)
{
	system("clear");
	cout << "请选择登录身份：" << endl;
	cout << "1、超级管理员" << endl;
	cout << "2、运营管理员" << endl;
	cout << "3、退出系统" << endl;
}
