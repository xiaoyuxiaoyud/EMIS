#include <iostream>
#include <fstream>
using namespace std;

int main(int argc,const char* argv[])
{
	ofstream fout("managers.dat");
	char buf[46] = {};
	int id = 0;
	char name[20] = {"admin"};
	char pwd[20] = {"123"};
	sprintf(buf,"%d %s %s",id,name,pwd);
	fout.write(buf,46);
}
