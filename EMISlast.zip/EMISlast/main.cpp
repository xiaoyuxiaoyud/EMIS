#include <iostream>
#include "tools.h"
#include "manager_view.h"
#include "emis.h"
#include "manager_view_impl.h"
#include "manager_ctrl_impl.h"

using namespace std;

int main(int argc,const char* argv[])
{
	ManagerViewImpl mgrvi;
	ManagerView& mgrv = mgrvi;
	for(;;)
	{
		main_show();
		switch(get_cmd('1','3'))
		{
			case '1':	mgrv.loginManager();	break;
			case '2':	mgrv.loginService();	break;
			case '3':	return 0;	break;
		}
	}
}
