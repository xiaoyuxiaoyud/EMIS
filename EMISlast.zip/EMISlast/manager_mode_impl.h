#ifndef MANAGER_MODE_IMPL_H
#define MANAGER_MODE_IMPL_H

#include "manager_mode.h"

class ManagerModeImpl : public ManagerMode
{
public:
	void load(vector<Manager>& mgrarr);
	void save(vector<Manager>& mgrarr);
};

#endif//MANAGER_MODE_IMPL_H
