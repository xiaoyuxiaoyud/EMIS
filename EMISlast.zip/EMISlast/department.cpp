#include "department.h"

void Department::setId(int id)
{
	m_Id = id;
}

void Department::setName(const char* name)
{
	strcpy(m_strName,name);
}

int Department::getId(void)
{
	return m_Id;
}

char* Department::getName(void)
{
	return m_strName;
}

ostream& operator<<(ostream& os,const Department& dept)
{
	os << dept.m_Id << " " << dept.m_strName << " ";
}

istream& operator>>(istream& is,Department& dept)
{
	is >> dept.m_Id >> dept.m_strName;
}

