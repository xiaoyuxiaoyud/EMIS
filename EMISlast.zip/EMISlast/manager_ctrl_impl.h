#ifndef MANAGER_CTRL_IMPL_H
#define MANAGER_CTRL_IMPL_H

#include <iostream>
#include <unistd.h>
#include "manager_ctrl.h"
#include "manager_mode.h"
#include "manager_mode_impl.h"
using namespace std;

class ManagerCtrlImpl : public ManagerCtrl
{
	vector<Manager> mgrarr;
	ManagerMode* mgrMode;
public:
	ManagerCtrlImpl(void)
	{
		mgrMode = new ManagerModeImpl;
		mgrMode->load(mgrarr);
	}
	~ManagerCtrlImpl(void)
	{
		mgrMode->save(mgrarr);
		delete mgrMode;
	}
	bool addMgr(Manager& mgr);
	bool delMgr(int id);
	vector<Manager>& listMgr(void);
};

#endif//MANAGER_CTRL_IMPL_H
