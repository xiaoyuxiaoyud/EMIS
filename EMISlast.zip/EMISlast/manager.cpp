#include "manager.h"

int Manager::getId(void)const
{
	return m_Id;
}

const char* Manager::getName(void)const
{
	return m_strName;
}

const char* Manager::getPwd(void)const
{
	return m_strPwd;
}

void Manager::setId(int id)
{
	m_Id=id;
}

void Manager::setName(const char* name)
{
	strcpy(m_strName,name);
}

void Manager::setPwd(const char* pwd)
{
	strcpy(m_strPwd,pwd);
}

