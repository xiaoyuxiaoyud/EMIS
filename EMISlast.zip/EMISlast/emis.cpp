#include "emis.h"


//ManagerCtrlImpl mgrci;
//ManagerCtrl& mgrv = mgrvi;
