#include <stdlib.h>
#include <iostream>
#include <fstream>
#include "service_view_impl.h"
using namespace std;

void ServiceViewImpl::menuSrc(void)
{
	while(true)
	{
		system("clear");
		cout << "***员工部门管理界面***" << endl;
		cout << "1、增加部门" << endl;
		cout << "2、删除部门" << endl;
		cout << "3、列出所有部门" << endl;
		cout << "4、增加员工" << endl;
		cout << "5、删除员工" << endl;
		cout << "6、修改员工星系" << endl;
		cout << "7、生成员工列表" << endl;
		cout << "8、列出所有员工" << endl;
		cout << "9、返回登录界面" << endl;
		stdin->_IO_read_ptr = stdin->_IO_read_end;
		switch(get_cmd('1','9'))
		{
			case '1':	addDept();	break;
			case '2':	delDept();	break;
			case '3':	listDept();	break;
			case '4':	addEmp();	break;
			case '5':	delEmp();	break;
			case '6':	modEmp();	break;
			case '7':	listEmp();	break;
			case '8':	listAllEmp();	break;
			case '9':	return;
		}
		stdin->_IO_read_ptr = stdin->_IO_read_end;
	}
}

void ServiceViewImpl::addDept(void)
{
	cout << "请输入部门名：";
	char name[20] = {};
	cin >> name;
	Department dept(name);
	if(srcCtrl->addDept(dept))
		cout << "添加部门成功" << endl;
	else
		cout << "添加部门失败" << endl;
	anykeycontinue();
}

void ServiceViewImpl::delDept(void)
{
	cout << "请输入部门ID：";
	int id = 0;
	cin >> id;
	if(srcCtrl->delDept(id))
		cout << "删除部门成功"  << endl;
	else
		cout << "删除部门失败" << endl;
	anykeycontinue(); 
}

void ServiceViewImpl::listDept(void)
{
	vector<Department>& deptArr = srcCtrl->listDept();
	for(vector<Department>::iterator it=deptArr.begin(); it!=deptArr.end(); it++)
	{
		cout << *it << endl;
	}
	anykeycontinue();
}

void ServiceViewImpl::addEmp(void)
{
	cout << "请输入部门ID：";
	int dept_id = 0;
	cin >> dept_id;
	cout << "请输入要添加的员工的姓名、性别、年龄：";
	char name[20] ={};
	char sex = 'm';
	int age = 0;
	cin >> name >> sex >> age;
	Employee emp(name,sex,age);
	if(srcCtrl->addEmp(dept_id,emp))
		cout << "添加员工成功" << endl;
	else
		cout << "添加员工失败" << endl;
	anykeycontinue();	
}

void ServiceViewImpl::delEmp(void)
{
	stdin->_IO_read_ptr = stdin->_IO_read_end;
	int id = 0; 
	cout << "请输入要删除的员工ID：" << endl;
	cin >> id;
	if(srcCtrl->delEmp(id))
		cout << "删除员工成功" << endl;
	else
		cout << "删除员工失败" << endl;
	anykeycontinue();
}

void ServiceViewImpl::modEmp(void)
{
	int id = 0;
	cout << "请输入要修改的员工ID：";
	cin >> id;
	cout << "1、姓名   2、年龄   3、性别   4、退出" << endl;
	cout << "请选择要修改的信息:";
	Employee emp;
	char name[20] ={};
	int age = 0;
	char sex = '\0';
	switch(get_cmd('1','4'))
	{
		case '1' :	cin >> name;	emp.setName(name);	break;
		case '2' :	cin >> age;	emp.setAge(age);	break;
		case '3' :	cin >> sex;	emp.setSex(sex);	break;
		case '4' :	return;
	}
	if(srcCtrl->modEmp(id,emp))
		cout << "修改成功" << endl;
	else
		cout << "查无此工号" << endl;
	anykeycontinue();
}

void ServiceViewImpl::listEmp(void)
{
	int id = 0;
	cout << "请输入部门ID：";
	cin >> id;
	Department* dept = srcCtrl->listEmp(id);
	if(dept == NULL)
	{
		cout << "查无此部门" << endl;
		anykeycontinue();
		return;
	}
	for(int i=0; i<dept->empArr.size(); i++)
	{
		cout << (dept->empArr)[i] << endl;
	}
	anykeycontinue();
}
	
void ServiceViewImpl::listAllEmp(void)
{
	vector<Department>& deptArr = srcCtrl->listAllEmp();
	for(int i=0; i<deptArr.size(); i++)
	{
		cout << deptArr[i] << endl;
		for(int j=0; j<deptArr[i].empArr.size(); j++)
		{
			cout << (deptArr[i].empArr)[j] << endl;
		}
	}
	anykeycontinue();
}

