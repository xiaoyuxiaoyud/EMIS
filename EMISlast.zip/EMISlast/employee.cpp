#include "employee.h"

void Employee::setId(int id)
{
	m_Id = id;
}

void Employee::setAge(int age)
{
	m_Age = age;
}

void Employee::setName(const char* name)
{
	strcpy(m_strName,name);
}

void Employee::setSex(char sex)
{
	m_cSex = sex;
}

int Employee::getId(void)
{
	return m_Id;
}

int Employee::getAge(void)
{
	return m_Age;
}

char* Employee::getName(void)
{
	return m_strName;
}

char Employee::getSex(void)
{
	return m_cSex;
}

ostream& operator<<(ostream& os,const Employee& emp)
{
	os << emp.m_Id << " " << emp.m_strName << " " << emp.m_cSex << " " << emp.m_Age;
}

istream& operator>>(istream& is,Employee& emp)
{
	is >> emp.m_Id >> emp.m_strName >> emp.m_cSex >> emp.m_Age;
}

