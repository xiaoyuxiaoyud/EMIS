#ifndef EMIS_H
#define EMIS_H

#include "manager_view.h"
#include "manager_ctrl.h"

extern ManagerView& mgrv;
//extern ManagerCtrl& mgrv

#endif//EMIS_H
