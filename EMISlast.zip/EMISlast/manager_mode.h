#ifndef MANAGER_MODE_H
#define MANAGER_MODE_H

#include <vector>
#include "manager.h"
using namespace std;

class ManagerMode
{
public:
	virtual void load(vector<Manager>& mgrarr) = 0;
	virtual void save(vector<Manager>& mgrarr) = 0;
};

#endif//MANAGER_MODE_H
