#include "service_ctrl_impl.h"

bool ServiceCtrlImpl::addDept(Department& dept)
{
	deptArr.insert(deptArr.end(),dept);
	return true;
}

int ServiceCtrlImpl::delDept(int id)
{
	for(vector<Department>::iterator it=deptArr.begin(); it!=deptArr.end(); it++)
	{
		if(id == it->getId())
		{
			deptArr.erase(it);
			return true;
		}
	}
	return false;
}

vector<Department>& ServiceCtrlImpl::listDept(void)
{
	return deptArr;
}

bool ServiceCtrlImpl::addEmp(int id,Employee& emp)
{
	for(vector<Department>::iterator it=deptArr.begin(); it!=deptArr.end(); it++)
	{
		if(id == it->getId())
		{
			it->empArr.insert(it->empArr.begin(),emp);
			return true;
		}
	}
	return false;
}

bool ServiceCtrlImpl::delEmp(int id)
{
	for(vector<Department>::iterator it=deptArr.begin(); it!=deptArr.end(); it++)
	{
		for(vector<Employee>::iterator eit=it->empArr.begin(); eit!=it->empArr.end(); eit++)
		{
			if(id == eit->getId())
			{
				it->empArr.erase(eit);
				return true;
			}
		}	
	}
	return false;
}

bool ServiceCtrlImpl::modEmp(int id,Employee& emp)
{
	for(vector<Department>::iterator it=deptArr.begin(); it!=deptArr.end(); it++)
	{
		for(vector<Employee>::iterator eit=it->empArr.begin(); eit!=it->empArr.end(); eit++)
		{
			if(id == eit->getId())
			{
				if(emp.getName())
					eit->setName(emp.getName());
				if(emp.getSex())
					eit->setSex(emp.getSex());
				if(emp.getAge())
					eit->setAge(emp.getAge());					
				return true;
			}
		}	
	}
	return false;
}

Department* ServiceCtrlImpl::listEmp(int id)
{
	for(vector<Department>::iterator it=deptArr.begin(); it!=deptArr.end(); it++)
	{
		if(id == it->getId())
		{
			return &(*it);
		}
	}
	return NULL;
}

vector<Department>& ServiceCtrlImpl::listAllEmp(void)
{
	return deptArr;
}

