#include <fstream>
#include "service_mode_impl.h"

void ServiceModeImpl::load(vector<Department>& deptArr)
{
	ifstream fin("services.dat");
	int index = -1;
	while(true)
	{
		Department dept;
		int cnt = 0;
		fin >> dept >> cnt;
		if(fin.eof())	break;
		deptArr.insert(deptArr.end(),dept);
		index ++;
		for(int i=0; i<cnt; i++)
		{
			Employee emp;
			fin >> emp;
			deptArr[index].empArr.insert(deptArr[index].empArr.end(),emp);
		}
		cout << "good" << endl;
	}
	fin.close();
}
	
void ServiceModeImpl::save(vector<Department>& deptArr)
{
	ofstream fout("services.dat");
	for(vector<Department>::iterator it=deptArr.begin(); it!=deptArr.end(); it++)
	{
		fout << *it << " " << it->empArr.size() << endl;
		for(vector<Employee>::iterator eit=it->empArr.begin(); eit!=it->empArr.end(); eit++)
		{
			fout << *eit << endl;
		}
	}
	fout.close();
}
